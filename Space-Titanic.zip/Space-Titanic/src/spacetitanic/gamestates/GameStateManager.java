package spacetitanic.gamestates;

import spacetitanic.GamePanel;

import java.awt.*;
import java.util.ArrayList;

public class GameStateManager {

    private GamePanel gamePanel;
    private ArrayList<State> gameStates = new ArrayList<>();

    public State startMenuState;
    public State playingState;
    public State stationState;

    public GameStateManager(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        initializeGameStates();
    }

    public void update() {
        switch (GameState.state) {
            case START_MENU -> {
            }
            case PLAYING -> {
            }
            case GAME_OVER -> {
            }
            case KILLED -> {
            }
            case STATION -> {
                gameStates.get(gameStates.size() - 2).update();
            }
            case STATION_STORAGE -> {
            }
            case STATION_BUY_SHIP -> {
            }
            case STATION_UPGRADE_SHIP -> {
            }
            case STATION_BUY_UPGRADE -> {
            }
        }
        peek().update();
    }

    public void render(Graphics2D g2) {
        switch (GameState.state) {
            case START_MENU -> {
            }
            case PLAYING -> {
            }
            case GAME_OVER -> {
            }
            case KILLED -> {
            }
            case STATION -> {
                gameStates.get(gameStates.size() - 2).render(g2);
            }
            case STATION_STORAGE -> {
            }
            case STATION_BUY_SHIP -> {
            }
            case STATION_UPGRADE_SHIP -> {
            }
            case STATION_BUY_UPGRADE -> {
            }
        }
        peek().render(g2);
        /* Maybe update more gamestates */
    }

    public ArrayList<State> getGameStates() {
        return gameStates;
    }

    public void push(State gamestate) {
        gameStates.add(gamestate);
    }

    public State peek() {
        return gameStates.get(gameStates.size() - 1);
    }

    public void pop() {
        gameStates.remove(gameStates.size() - 1);
        GameState.state = gameStates.get(gameStates.size() - 1).getGameState();
    }

    private void initializeGameStates() {
        startMenuState = new StartMenuState(gamePanel);
        playingState = new PlayingState(gamePanel);
        stationState = new StationState(gamePanel);

        /* Add and set startmenu as the first state */
        gameStates.add(startMenuState);
        GameState.state = GameState.START_MENU;
    }


}
