package spacetitanic.gameobjects.abilities;

public interface Destroyable {


    public void destroyed();

    public void takeDamage(int damage);

    /*public boolean isTargeted();*/

    /*public void setTargeted();*/

}
