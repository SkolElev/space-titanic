package spacetitanic.gameobjects.abilities;

public interface Profit {

    /* Add an int value */

    /* Generate Resource of the given value */
    public void generateResource(int value);
}
