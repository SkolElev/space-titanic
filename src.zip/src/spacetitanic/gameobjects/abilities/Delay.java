package spacetitanic.gameobjects.abilities;

public interface Delay {

    public boolean isDelayed();

    public boolean checkDelayed();




}
