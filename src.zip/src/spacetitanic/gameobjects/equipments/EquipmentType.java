package spacetitanic.gameobjects.equipments;

public enum EquipmentType {
    CANNON, AUTOCANNON, MISSILE, BEAM, MINE, SHIELD, DEPLOYABLE, RADAR, AUTOMATED;
}
