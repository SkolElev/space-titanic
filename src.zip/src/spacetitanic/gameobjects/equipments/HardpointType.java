package spacetitanic.gameobjects.equipments;

public enum HardpointType {
    GENERAL, WEAPON, UTILITY, SHIELD;
}
