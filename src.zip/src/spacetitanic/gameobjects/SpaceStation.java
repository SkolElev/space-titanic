package spacetitanic.gameobjects;

import spacetitanic.GamePanel;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class SpaceStation extends GameObject {

    private int width, height;
    private Point2D spawnPoint;

    public SpaceStation(GamePanel gamePanel, int x, int y) {
        this.gamePanel = gamePanel;
        this.x = x;
        this.y = y;
        images = new BufferedImage[1];
        images[0] = gamePanel.graphics.stationImage;
        width = images[0].getWidth();
        height = images[0].getHeight();
        collisionShape = new Rectangle2D.Double(50 * gamePanel.scaleX - width / 2, -60 * gamePanel.scaleY,
                180 * gamePanel.scaleX, 120 * gamePanel.scaleY);
        speed = 0.03 * gamePanel.scaleX;
        rotationSpeed = 0.008;
        direction = Math.random() * 360.0;
        velocityVector.set(Math.cos(Math.toRadians(direction)) * speed, Math.sin(Math.toRadians(direction)) * speed);
        spawnPoint = new Point2D.Double(100 * gamePanel.scaleX, 0.0);
        name = "Scavenger Station";
    }

    @Override
    public void update() {
        x += velocityVector.x;
        y += velocityVector.y;

        x = (x + gamePanel.worldWidth) % gamePanel.worldWidth;
        y = (y + gamePanel.worldHeight) % gamePanel.worldHeight;

        positionVector.set(x, y);
        rotation += rotationSpeed;
    }

    @Override
    protected void renderObject(Graphics2D g2, double positionX, double positionY) {
        AffineTransform old = g2.getTransform();
        objectTransform = new AffineTransform();
        objectTransform.translate(positionX, positionY);
        objectTransform.rotate(Math.toRadians(rotation));
        g2.transform(objectTransform);

        g2.drawImage(images[0], -width / 2, -height / 2, width, height, null);

        g2.setColor(Color.orange);
        g2.draw(collisionShape);

        g2.drawOval((int) (spawnPoint.getX() - 20), (int) (spawnPoint.getY() - 20), 40, 40);

        g2.setTransform(old);
    }


}
