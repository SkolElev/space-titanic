package spacetitanic.gamestates;

import spacetitanic.GamePanel;
import spacetitanic.gamestates.buttons.Button;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class StationState implements State {
    private GamePanel gamePanel;
    public GameState thisGameState = GameState.STATION;
    private ArrayList<Button> buttons = new ArrayList<>();

    private BufferedImage backgroundImage;

    public StationState(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        initialize();
    }

    private void initialize() {
        backgroundImage = gamePanel.graphics.stationBackground;
    }

    @Override
    public void update() {
        if (gamePanel.input.isKeyDown(KeyEvent.VK_ESCAPE)) {
            gamePanel.gameStateManager.pop();
        }
    }

    @Override
    public void render(Graphics2D g2) {
        int panelX = (int) (gamePanel.screenWidth / 2 - backgroundImage.getWidth() * gamePanel.scaleX / 2);
        int panelY = (int) (gamePanel.screenHeight / 2 - backgroundImage.getHeight() * gamePanel.scaleY / 2);
        g2.drawImage(backgroundImage, panelX, panelY, (int) (backgroundImage.getWidth() * gamePanel.scaleX),
                (int) (backgroundImage.getWidth() * gamePanel.scaleX), null);
    }

    @Override
    public GameState getGameState() {
        return thisGameState;
    }

}
