package spacetitanic.gamestates;

import spacetitanic.GamePanel;
import spacetitanic.gamestates.buttons.Button;
import spacetitanic.gamestates.buttons.StationButton;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class StationState implements State {
    private GamePanel gamePanel;
    public GameState thisGameState = GameState.STATION;
    private ArrayList<Button> buttons = new ArrayList<>();
    int panelX, panelY;

    private BufferedImage backgroundImage;

    public StationState(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        initialize();
    }

    private void initialize() {
        backgroundImage = gamePanel.graphics.stationBackground;
        panelX = (int) (gamePanel.screenWidth / 2 - backgroundImage.getWidth() * gamePanel.scaleX / 2);
        panelY = (int) (gamePanel.screenHeight / 2 - backgroundImage.getHeight() * gamePanel.scaleY / 2);
        int backgroundX = (int) (panelX + 270 * gamePanel.scaleX);
        int backgroundY = (int) (panelY + 63 * gamePanel.scaleY);
        Button button = new StationButton(gamePanel, backgroundX, backgroundY, "Sell Resource");
        buttons.add(button);
    }

    @Override
    public void update() {
        if (gamePanel.input.isKeyDown(KeyEvent.VK_ESCAPE)) {
            gamePanel.gameStateManager.pop();
        }
        for (Button button : buttons) {
            button.update();
        }
    }

    @Override
    public void render(Graphics2D g2) {
        g2.drawImage(backgroundImage, panelX, panelY, (int) (backgroundImage.getWidth() * gamePanel.scaleX),
                (int) (backgroundImage.getHeight() * gamePanel.scaleY), null);
        for (Button button : buttons) {
            button.render(g2);
        }
    }

    @Override
    public GameState getGameState() {
        return thisGameState;
    }

}
