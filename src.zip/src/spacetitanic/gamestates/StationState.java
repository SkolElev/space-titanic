package spacetitanic.gamestates;

import spacetitanic.GamePanel;
import spacetitanic.gameobjects.Resource;
import spacetitanic.gamestates.buttons.Button;
import spacetitanic.gamestates.buttons.StationButton;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class StationState implements State {
    private GamePanel gamePanel;
    public GameState thisGameState = GameState.STATION;
    private ArrayList<Button> buttons = new ArrayList<>();
    private ArrayList<Resource> soldResources = new ArrayList<>();
    int panelX, panelY;

    private BufferedImage backgroundImage;

    public StationState(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        initialize();
    }

    private void initialize() {
        backgroundImage = gamePanel.graphics.stationBackground;
        panelX = (int) (gamePanel.screenWidth / 2 - backgroundImage.getWidth() * gamePanel.scaleX / 2);
        panelY = (int) (gamePanel.screenHeight / 2 - backgroundImage.getHeight() * gamePanel.scaleY / 2);
        int backgroundX = (int) (panelX + 270 * gamePanel.scaleX);
        int backgroundY = (int) (panelY + 63 * gamePanel.scaleY);
        int buttonStep = (int) (48 * gamePanel.scaleY);
        Button button = new StationButton(gamePanel, backgroundX, backgroundY, "Sell Resource");
        buttons.add(button);
        button = new StationButton(gamePanel, backgroundX, backgroundY + buttonStep * 1, "Storage");
        buttons.add(button);
        button = new StationButton(gamePanel, backgroundX, backgroundY + buttonStep * 2, "Buy Upgrades");
        buttons.add(button);
        button = new StationButton(gamePanel, backgroundX, backgroundY + buttonStep * 3, "Buy Ship");
        buttons.add(button);
        button = new StationButton(gamePanel, backgroundX, backgroundY + buttonStep * 4, "Upgrade Ship");
        buttons.add(button);
        button = new StationButton(gamePanel, backgroundX, backgroundY + buttonStep * 5, "Leave Station");
        buttons.add(button);
    }

    @Override
    public void update() {
        if (gamePanel.input.isKeyDown(KeyEvent.VK_O)) {
            gamePanel.changeGameState(GameState.PLAYING);
        }
        for (Button button : buttons) {
            button.update();
            if (gamePanel.input.isButtonUp(1) && button.isHit(gamePanel.input.getMouseX(), gamePanel.input.getMouseY())) {
                switch (button.getText()) {
                    case "Sell Resource":
                        System.out.println("Selling Resources");

                        for (Resource resource : gamePanel.player.getShip().getCargoSpace()) {

                        }
                        break;
                    case "Storage":
                        System.out.println("Opening Storage");
                        break;
                    case "Buy Upgrades":
                        System.out.println("Buying Upgrades");
                        break;
                    case "Buy Ship":
                        System.out.println("Buying a new Ship");
                        break;
                    case "Upgrade Ship":
                        System.out.println("Upgrading a Ship");
                        break;
                    case "Leave Station":
                        System.out.println("Leaving the Space Station");
                        gamePanel.gameStateManager.pop();
                        break;
                    default:
                        break;
                }
            }
        }
    }

    @Override
    public void render(Graphics2D g2) {
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, 0, gamePanel.worldWidth, gamePanel.worldHeight);
        /* Background */
        g2.setColor(new Color(255, 255, 255, 100));
        g2.drawRect(0, 0, gamePanel.worldWidth, gamePanel.worldHeight);
        g2.drawImage(backgroundImage, panelX, panelY, (int) (backgroundImage.getWidth() * gamePanel.scaleX),
                (int) (backgroundImage.getHeight() * gamePanel.scaleY), null);
        /* Station Name */
        g2.setFont(gamePanel.graphics.axaxaxBig);
        g2.setColor(Color.orange);
        g2.drawString("Scavanger Station", (int) (panelX + 142 * gamePanel.scaleX), (int) (panelY + 54 * gamePanel.scaleY));
        /* Buttons */
        for (Button button : buttons) {
            button.render(g2);
        }
        drawCargoSpace(g2);
    }

    private void drawCargoSpace(Graphics2D g2) {
        /* Cargo panel */
        int positionX = (int) (panelX + 38 * gamePanel.scaleX);
        int positionY = (int) (panelY + 278 * gamePanel.scaleY);

        int row = 0, column = 0, nextRow = 100, sizeX = (int) (210 * gamePanel.scaleX), sizeY = (int) (47 * gamePanel.scaleY);
        int cargoSpaceSize = gamePanel.player.getShip().getCargoSpaceSize();
        int subPositionX = (int) (positionX + 8 * gamePanel.scaleX);
        int subPositionY = (int) (positionY + 20 * gamePanel.scaleY);

        if (cargoSpaceSize >= 33) {
            nextRow = cargoSpaceSize / 4 + cargoSpaceSize % 4;
            sizeX = sizeX / nextRow;
            sizeY = sizeY / 4;
        } else if (cargoSpaceSize >= 21) {
            nextRow = cargoSpaceSize / 3 + cargoSpaceSize % 3;
            sizeX = sizeX / nextRow;
            sizeY = sizeY / 3;
        } else if (cargoSpaceSize > 10) {
            nextRow = cargoSpaceSize / 2 + cargoSpaceSize % 2;
            sizeX = sizeX / nextRow;
            sizeY = sizeY / 2;
        } else {
            sizeX = sizeX / cargoSpaceSize;
            sizeY = sizeX;
            subPositionY = subPositionY + sizeY / 4;
        }

        g2.setColor(Color.orange);
        for (int i = 0; i < cargoSpaceSize; i++) {
            g2.drawRect(subPositionX + column * sizeX, subPositionY + row * sizeY, sizeX, sizeY);
            column++;
            if (i > 0 && (i + 1) % nextRow == 0) {
                row++;
                column = 0;
            }
        }

        /* The graphics for cargoSpace */
        column = 0;
        row = 0;
        int cargoSpace = gamePanel.player.getShip().getCargoSpace().size();
        ArrayList<Resource> resources = gamePanel.player.getShip().getCargoSpace();
        for (int i = 0; i < cargoSpace; i++) {
            g2.drawImage(gamePanel.player.getShip().getCargoSpace().get(i).getImages()[0],
                    subPositionX + column * sizeX, subPositionY + row * sizeY, sizeX, sizeY, null);
            resources.get(i).setCargoX(subPositionX + column * sizeX + panelX);
            resources.get(i).setCargoY(subPositionY + row * sizeY + panelY);
            column++;
            if (i > 0 && (i + 1) % nextRow == 0) {
                row++;
                column = 0;
            }
        }

    }

    @Override
    public GameState getGameState() {
        return thisGameState;
    }


}
