package spacetitanic.gamestates;

import spacetitanic.GamePanel;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

public class PlayingState implements State {
    GamePanel gamePanel;
    public GameState thisGameState = GameState.PLAYING;

    public PlayingState(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    @Override
    public void update() {
        if (gamePanel.input.isKeyDown(KeyEvent.VK_ESCAPE)) {
            /*System.out.println("Exited Playing State");*/
            gamePanel.gameStateManager.pop();
        }

        if (GameState.state == GameState.PLAYING) {
            if (gamePanel.input.isKeyDown(KeyEvent.VK_O)) {
                gamePanel.changeGameState(GameState.STATION);
                if (gamePanel.gameStateManager.peek() instanceof StationState station) {
                    station.setSoldResources(gamePanel.player.getShip().getResources());
                }

            }
            gamePanel.player.update();
        }
        gamePanel.map.update();
    }

    @Override
    public void render(Graphics2D g2) {
        if (gamePanel.map != null) {
            gamePanel.map.render(g2);
        }

        /* Credz */
        g2.setFont(gamePanel.graphics.axaxaxMicro);
        g2.setColor(Color.orange);
        g2.drawString(gamePanel.player.getCredz() + " £", (int) (120 * gamePanel.scaleX), (int) (20 * gamePanel.scaleY));

        /* Main backpanel */
        g2.drawImage(gamePanel.graphics.backpanel, 0, (int) (gamePanel.screenHeight - gamePanel.graphics.backpanel.getHeight() * gamePanel.scaleY),
                (int) (gamePanel.screenWidth), (int) (gamePanel.graphics.backpanel.getHeight() * gamePanel.scaleY), null);

        /* Weapon panel */
        renderWeaponPanel(g2);

        /* Cargo panel */
        renderCargoPanel(g2);

        /* Render drop cargo */

        g2.setFont(gamePanel.graphics.axaxaxMicro);
        gamePanel.player.render(g2);
    }

    private void renderCargoPanel(Graphics2D g2) {
        /* Cargo panel */
        int positionX = (int) (gamePanel.screenWidth / 2 - gamePanel.graphics.cargoPanel.getWidth() * gamePanel.scaleX - 135 * gamePanel.scaleX);
        int positionY = (int) (gamePanel.screenHeight - gamePanel.graphics.cargoPanel.getHeight() * gamePanel.scaleY * 0.9);
        g2.drawImage(gamePanel.graphics.cargoPanel, positionX, positionY, (int) (gamePanel.graphics.cargoPanel.getWidth() * gamePanel.scaleX),
                (int) (gamePanel.graphics.cargoPanel.getHeight() * gamePanel.scaleY), null);

        int row = 0, column = 0, nextRow = 100, sizeX = (int) (210 * gamePanel.scaleX), sizeY = (int) (47 * gamePanel.scaleY);
        int cargoSpaceSize = gamePanel.player.getShip().getCargoSpaceSize();
        int panelX = (int) (positionX + 8 * gamePanel.scaleX);
        int panelY = (int) (positionY + 20 * gamePanel.scaleY);

        if (cargoSpaceSize >= 33) {
            nextRow = cargoSpaceSize / 4 + cargoSpaceSize % 4;
            sizeX = sizeX / nextRow;
            sizeY = sizeY / 4;
        } else if (cargoSpaceSize >= 21) {
            nextRow = cargoSpaceSize / 3 + cargoSpaceSize % 3;
            sizeX = sizeX / nextRow;
            sizeY = sizeY / 3;
        } else if (cargoSpaceSize > 10) {
            nextRow = cargoSpaceSize / 2 + cargoSpaceSize % 2;
            sizeX = sizeX / nextRow;
            sizeY = sizeY / 2;
        } else {
            sizeX = sizeX / cargoSpaceSize;
            sizeY = sizeX;
            panelY = panelY + sizeY / 4;
        }

        g2.setColor(new Color(60, 60, 60, 150));
        for (int i = 0; i < cargoSpaceSize; i++) {
            g2.drawRect(panelX + column * sizeX, panelY + row * sizeY, sizeX, sizeY);

            column++;
            if (i > 0 && (i + 1) % nextRow == 0) {
                row++;
                column = 0;
            }
        }

        /* The graphics for cargoSpace */
        column = 0;
        row = 0;
        int cargoSpace = gamePanel.player.getShip().getResources().size();
        for (int i = 0; i < cargoSpace; i++) {
            g2.drawImage(gamePanel.player.getShip().getResources().get(i).getImages()[0],
                    panelX + column * sizeX, panelY + row * sizeY, sizeX, sizeY, null);
            column++;
            if (i > 0 && (i + 1) % nextRow == 0) {
                row++;
                column = 0;
            }
        }

    }

    private void renderWeaponPanel(Graphics2D g2) {
        /* Weapon panel */
        int positionX = (int) (gamePanel.screenWidth / 2 + 100 * gamePanel.scaleX);
        int positionY = (int) (gamePanel.screenHeight - gamePanel.graphics.weaponPanel.getHeight() * gamePanel.scaleY * 0.9);
        g2.drawImage(gamePanel.graphics.weaponPanel, positionX, positionY, (int) (gamePanel.graphics.weaponPanel.getWidth() * gamePanel.scaleX),
                (int) (gamePanel.graphics.weaponPanel.getHeight() * gamePanel.scaleY),
                null);
        /* Equipment name */
        g2.setFont(gamePanel.graphics.axaxaxSmall);
        g2.setColor(Color.orange);
        g2.drawString(gamePanel.player.getShip().getWeapon().getEquipmentName(), (int) (positionX + 60 * gamePanel.scaleX),
                (int) (positionY + 25 * gamePanel.scaleY));
        if (gamePanel.player.getShip().getWeapon().isReloading()) {
            g2.setColor(Color.red);
        }
        /* Ammo amount */
        g2.drawString(String.valueOf(gamePanel.player.getShip().getWeapon().getAmmo()), (int) (positionX + 10 * gamePanel.scaleX),
                (int) (positionY + 57 * gamePanel.scaleY));
        /* Ammo image */
        BufferedImage ammoImage = gamePanel.player.getShip().getWeapon().getAmmoImage();
        int width = 152;
        double step = (double) width / gamePanel.player.getShip().getWeapon().getMaxAmmo() * gamePanel.scaleX;
        for (int i = 0; i < gamePanel.player.getShip().getWeapon().getAmmo(); i++) {
            g2.drawImage(ammoImage, (int) (positionX + 62 * gamePanel.scaleX + step * i),
                    (int) (positionY + 39 * gamePanel.scaleY), (int) (ammoImage.getWidth() * gamePanel.scaleX), (int) (ammoImage.getHeight() * gamePanel.scaleY), null);
        }
    }

    @Override
    public GameState getGameState() {
        return thisGameState;
    }
}
