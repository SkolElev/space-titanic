package spacetitanic.gamestates.buttons;

import spacetitanic.GamePanel;

import java.awt.*;
import java.awt.geom.Area;
import java.awt.image.BufferedImage;


public class StationButton extends Button {
    BufferedImage image;

    public StationButton(GamePanel gamePanel, int x, int y, String text) {
        this.x = x;
        this.y = y;
        this.text = text;
        this.gamePanel = gamePanel;
        double scaleX = gamePanel.scaleX;
        double scaleY = gamePanel.scaleY;
        int[] xPoints = {(int) (10 * scaleX), (int) (190 * scaleX), (int) (190 * scaleX), (int) (180 * scaleX), (int) (10 * scaleX)};
        int[] yPoints = {(int) (10 * scaleY), (int) (10 * scaleY), (int) (40 * scaleY), (int) (50 * scaleY), (int) (50 * scaleY)};
        Polygon polygon = new Polygon(xPoints, yPoints, xPoints.length);
        area = new Area(polygon);
        localTransform.translate(x, y);
        area.transform(localTransform);
        normalImage = new BufferedImage[1];
        hoverImage = new BufferedImage[1];
        pressedImage = new BufferedImage[1];
        normalImage[0] = gamePanel.graphics.stationButtonDefault;
        hoverImage[0] = gamePanel.graphics.stationButtonHover;
        pressedImage[0] = gamePanel.graphics.stationButtonPressed;
        textColor = Color.orange;
        image = normalImage[0];
    }

    @Override
    public void update() {
        if (isHit(gamePanel.input.getMouseX(), gamePanel.input.getMouseY()) && gamePanel.input.isButton(1)) {
            /* button pressed state */
            pressed = true;
            hover = false;
            image = pressedImage[0];
            textColor = Color.orange.darker();
        } else if (isHit(gamePanel.input.getMouseX(), gamePanel.input.getMouseY())) {
            /* button hover state */
            hover = true;
            pressed = false;
            image = hoverImage[0];
            textColor = Color.orange.brighter();
        } else {
            /* button normal state */
            hover = false;
            pressed = false;
            image = normalImage[0];
            textColor = Color.orange;
        }

    }

    @Override
    public void render(Graphics2D g2) {
        /* Code that will be used at a later time */
        if (image != null) {
            /* Draw image */
            g2.drawImage(image, (int) localTransform.getTranslateX(), (int) localTransform.getTranslateY(),
                    (int) (image.getWidth() * gamePanel.scaleX), (int) (image.getHeight() * gamePanel.scaleY), null);
        }
        g2.setFont(gamePanel.graphics.axaxaxSmall);
        g2.setColor(textColor);
        g2.drawString(text, (int) (x + 20 * gamePanel.scaleX), (int) (y + 42 * gamePanel.scaleY));
    }
}
