package spacetitanic.gamestates;

import spacetitanic.gameobjects.Resource;

import java.awt.*;
import java.util.ArrayList;

public interface State {

    public void update();

    public void render(Graphics2D g2);

    public GameState getGameState();

}
